# Clara.com - Asisten AI UMKM

Ini adalah web statis untuk Clara, asisten AI yang membantu UMKM Indonesia.

## Cara Menjalankan

1. Buka folder `WEB`.
2. Buka file `index.html` di browser (PC atau Android).

## Struktur
- `index.html` — Halaman utama web statis Clara.
- `README.md` — Penjelasan singkat project.

---

Silakan modifikasi sesuai kebutuhan Anda. 